# 🥷 SF2 AI Bot — Android App

App chạy thẳng trên điện thoại, **không cần máy tính, không cần root, không cần ADB**.  
Treo qua đêm → AI tự học pattern → ngày càng né chiêu hoàn hảo hơn.

---

## 📱 Yêu cầu

| Thứ | Chi tiết |
|-----|---------|
| Android | **10+** (API 29+) |
| RAM | 3GB+ khuyến nghị |
| Root | ❌ Không cần |
| ADB | ❌ Không cần |
| Kết nối mạng | ❌ Không cần — AI học offline hoàn toàn |

---

## 🏗️ Cấu trúc source code

```
SF2BotApp/
├── app/src/main/
│   ├── java/com/sf2bot/
│   │   ├── ai/
│   │   │   └── SF2AIEngine.java     ← Toàn bộ AI (Vision + Learning + Decision)
│   │   ├── service/
│   │   │   ├── BotAccessibilityService.java  ← Chụp màn hình + inject touch
│   │   │   └── BotForegroundService.java     ← Giữ process sống qua đêm
│   │   ├── ui/
│   │   │   ├── MainActivity.java    ← Dashboard điều khiển
│   │   │   └── CalibrateActivity.java ← Setup vị trí nút
│   │   └── utils/
│   │       ├── BotConfig.java       ← Lưu/load tọa độ
│   │       └── DataSaver.java       ← Lưu data AI học
│   └── res/
│       ├── layout/                  ← XML layouts
│       └── xml/accessibility_service_config.xml
└── app/build.gradle
```

---

## 🛠️ Build APK

### Cách 1: Android Studio (đơn giản nhất)
1. Tải [Android Studio](https://developer.android.com/studio)
2. **File → Open** → chọn thư mục `SF2BotApp`
3. Chờ Gradle sync xong
4. **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. APK ở: `app/build/outputs/apk/debug/app-debug.apk`

### Cách 2: Command line
```bash
cd SF2BotApp
./gradlew assembleDebug
# APK tại: app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 Cài và chạy lần đầu

### Bước 1: Cài APK
- Copy APK sang điện thoại → mở file → **Cài đặt**
- Nếu bị chặn: Cài đặt → Bảo mật → Cho phép cài từ nguồn không rõ

### Bước 2: Bật Accessibility Service
```
Cài đặt → Trợ năng (Accessibility)
→ Ứng dụng đã cài đặt (Installed apps)
→ SF2 Bot Service
→ Bật (toggle ON)
→ Cho phép (Allow)
```

### Bước 3: Cho phép hiển thị overlay
```
Cài đặt → Ứng dụng → SF2 AI Bot
→ Quyền đặc biệt → Hiển thị trên ứng dụng khác → Cho phép
```

### Bước 4: Calibrate nút bấm
1. Mở SF2, vào trận đấu (để thấy giao diện chiến đấu)
2. **Chuyển sang SF2 AI Bot app**
3. Bấm **"CALIBRATE VỊ TRÍ NÚT BẤM"**
4. App sẽ hiện overlay trong suốt — **chạm đúng vào từng nút** theo hướng dẫn
5. 8 nút: Trái, Phải, Đấm, Đá, Nhảy, Block, Vũ khí, Magic

### Bước 5: Bắt đầu!
1. Mở SF2, vào trận
2. Chuyển sang SF2 AI Bot → bấm **▶ BẮT ĐẦU**
3. Cho phép chụp màn hình khi hỏi
4. **Chuyển lại SF2** — Bot bắt đầu chơi tự động! 🤖

---

## 🧠 AI học như thế nào?

```
Trận 1-10:
  Bot dùng bảng né cứng (hard-coded dodge table)
  Bắt đầu ghi nhớ chuỗi đòn địch

Trận 10-50:
  N-gram Markov đủ data để dự đoán 30-40% đòn trước khi ra
  Q-Learning bắt đầu cải thiện combo attack

Trận 50-200:
  Pattern memory dự đoán >60% đòn tiếp theo
  Punish window timing ngày càng chính xác
  
Trận 200+:
  Bot đã học đặc điểm riêng của từng boss/enemy
  Né chiêu gần như hoàn hảo với enemy quen thuộc
```

**Data được lưu tự động** mỗi 5 phút vào bộ nhớ trong.  
Tắt app, bật lại → bot tiếp tục từ nơi đã học! ✅

---

## 📊 Đọc Dashboard

| Chỉ số | Ý nghĩa |
|--------|---------|
| 🛡️ DODGING | Đang né chiêu thực tế |
| 🔮 THREAT | Đang né dựa trên dự đoán pattern |
| ⚔️ PUNISHING | Đang phản công khi địch recovery |
| 🥊 COMBOING | Đang tung combo |
| 💨 RETREATING | HP nguy hiểm, đang rút lui |
| Observations | Tổng số lần địch ra đòn đã học |
| Frames | Số frame đã xử lý |

---

## ⚠️ Lưu ý

- App cần **màn hình ON** để chụp frame (hoặc dùng `adb shell settings put system screen_off_timeout 2147483647` để tắt timeout)
- **Cắm sạc** khi treo bot qua đêm
- Bot chỉ hoạt động khi **SF2 đang ở màn trước** (foreground)
- Mỗi boss/enemy có pattern khác nhau → cần thời gian học riêng

---

## 🐛 Troubleshooting

| Vấn đề | Giải pháp |
|--------|-----------|
| Bot không bấm gì | Kiểm tra Accessibility Service đã bật chưa |
| Bấm sai vị trí | Chạy lại Calibrate với SF2 đang mở |
| App bị kill | Bật "Không tối ưu hóa pin" cho SF2 AI Bot |
| Build lỗi | Kiểm tra Android SDK 34 đã cài trong Android Studio |
