package com.sf2bot.utils;

import android.content.Context;
import android.util.Log;

import com.sf2bot.ai.SF2AIEngine;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

import java.io.*;
import java.util.Map;

/**
 * Lưu/load data học của AI:
 * - patterns.json : N-gram pattern memory
 * - qtable.json   : Q-Learning table
 */
public class DataSaver {
    private static final String TAG = "DataSaver";
    private final File dataDir;

    public DataSaver(Context ctx) {
        dataDir = new File(ctx.getFilesDir(), "sf2bot_data");
        dataDir.mkdirs();
        Log.i(TAG, "Data dir: " + dataDir.getAbsolutePath());
    }

    public void saveAll(SF2AIEngine engine) {
        try {
            savePatterns(engine);
            saveQTable(engine);
            Log.i(TAG, "✅ Data saved. Observations: "
                    + engine.getPatternMemory().getTotalObservations());
        } catch (Exception e) {
            Log.e(TAG, "Save error: " + e.getMessage());
        }
    }

    private void savePatterns(SF2AIEngine engine) throws IOException, JSONException {
        Map<String, Object> data = engine.getPatternMemory().serialize();
        JSONObject json = mapToJson(data);
        writeFile("patterns.json", json.toString(2));
    }

    private void saveQTable(SF2AIEngine engine) throws IOException, JSONException {
        JSONObject root = new JSONObject();
        for (Map.Entry<String, Map<SF2AIEngine.BotAction, Float>> stateEntry
                : engine.getQLearning().getQTable().entrySet()) {
            JSONObject actions = new JSONObject();
            for (Map.Entry<SF2AIEngine.BotAction, Float> ae
                    : stateEntry.getValue().entrySet()) {
                actions.put(ae.getKey().name(), ae.getValue().doubleValue());
            }
            root.put(stateEntry.getKey(), actions);
        }
        writeFile("qtable.json", root.toString(2));
    }

    public void loadPatterns(SF2AIEngine engine) {
        // Patterns tự load trong PatternMemory khi khởi tạo nếu cần
        // Đây là placeholder cho future implementation
        Log.i(TAG, "Pattern memory initialized fresh (previous session data ignored for simplicity)");
    }

    private void writeFile(String name, String content) throws IOException {
        File f = new File(dataDir, name);
        try (FileWriter fw = new FileWriter(f)) {
            fw.write(content);
        }
        Log.d(TAG, "Wrote: " + f.getName() + " (" + content.length() + " chars)");
    }

    private JSONObject mapToJson(Map<String, Object> map) throws JSONException {
        JSONObject obj = new JSONObject();
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (e.getValue() instanceof Map) {
                obj.put(e.getKey(), mapToJson((Map<String,Object>)e.getValue()));
            } else if (e.getValue() instanceof Integer) {
                obj.put(e.getKey(), (Integer)e.getValue());
            } else {
                obj.put(e.getKey(), e.getValue().toString());
            }
        }
        return obj;
    }

    public File getDataDir() { return dataDir; }
}
