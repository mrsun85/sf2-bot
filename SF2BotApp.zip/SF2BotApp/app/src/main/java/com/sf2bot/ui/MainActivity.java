package com.sf2bot.ui;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;
import android.provider.Settings;

import com.sf2bot.R;
import com.sf2bot.ai.SF2AIEngine;
import com.sf2bot.service.BotAccessibilityService;

/**
 * Màn hình chính:
 * - Bật/tắt bot
 * - Calibrate nút bấm
 * - Xem stats realtime
 * - Quản lý session học
 */
public class MainActivity extends Activity {

    private static final int REQ_MEDIA_PROJ = 1001;
    private static final int REQ_OVERLAY    = 1002;

    // Views
    private Button  btnStart, btnStop, btnCalibrate;
    private TextView tvStatus, tvStats, tvBrainState;
    private TextView tvDodges, tvPunishes, tvCombos, tvWinLoss;
    private ProgressBar pbPlayerHp, pbEnemyHp;
    private Switch swAutoRetry, swSaveData;
    private LinearLayout layoutStats;
    private View  dotRunning;

    private MediaProjectionManager projManager;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable statsUpdater;
    private boolean serviceReady = false;

    // Receiver khi service sẵn sàng
    private final BroadcastReceiver serviceReadyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent i) {
            serviceReady = true;
            runOnUiThread(() -> {
                tvStatus.setText("✅ Service đã sẵn sàng");
                btnStart.setEnabled(true);
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        setupListeners();

        projManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(serviceReadyReceiver,
                new IntentFilter("com.sf2bot.SERVICE_READY"),
                RECEIVER_NOT_EXPORTED);

        checkPermissions();
        startStatsUpdater();
    }

    private void bindViews() {
        btnStart      = findViewById(R.id.btnStart);
        btnStop       = findViewById(R.id.btnStop);
        btnCalibrate  = findViewById(R.id.btnCalibrate);
        tvStatus      = findViewById(R.id.tvStatus);
        tvStats       = findViewById(R.id.tvStats);
        tvBrainState  = findViewById(R.id.tvBrainState);
        tvDodges      = findViewById(R.id.tvDodges);
        tvPunishes    = findViewById(R.id.tvPunishes);
        tvCombos      = findViewById(R.id.tvCombos);
        tvWinLoss     = findViewById(R.id.tvWinLoss);
        pbPlayerHp    = findViewById(R.id.pbPlayerHp);
        pbEnemyHp     = findViewById(R.id.pbEnemyHp);
        swAutoRetry   = findViewById(R.id.swAutoRetry);
        swSaveData    = findViewById(R.id.swSaveData);
        layoutStats   = findViewById(R.id.layoutStats);
        dotRunning    = findViewById(R.id.dotRunning);
        btnStart.setEnabled(false);
        btnStop.setEnabled(false);
        layoutStats.setVisibility(View.GONE);
    }

    private void setupListeners() {
        btnStart.setOnClickListener(v -> requestMediaProjection());
        btnStop.setOnClickListener(v -> stopBot());
        btnCalibrate.setOnClickListener(v ->
            startActivity(new Intent(this, CalibrateActivity.class))
        );
    }

    private void checkPermissions() {
        // 1. Kiểm tra Accessibility Service
        if (!isAccessibilityEnabled()) {
            tvStatus.setText("⚠️ Cần bật Accessibility Service");
            showAccessibilityDialog();
            return;
        }
        // 2. Kiểm tra Overlay permission
        if (!Settings.canDrawOverlays(this)) {
            tvStatus.setText("⚠️ Cần quyền hiển thị overlay");
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            startActivityForResult(intent, REQ_OVERLAY);
            return;
        }
        tvStatus.setText("🔍 Đang chờ Accessibility Service...");
        // Service đã chạy sẵn?
        if (BotAccessibilityService.getInstance() != null) {
            serviceReady = true;
            tvStatus.setText("✅ Service đã sẵn sàng");
            btnStart.setEnabled(true);
        }
    }

    private boolean isAccessibilityEnabled() {
        int enabled = 0;
        try {
            enabled = Settings.Secure.getInt(
                getContentResolver(),
                Settings.Secure.ACCESSIBILITY_ENABLED
            );
        } catch (Exception ignored) {}
        if (enabled == 0) return false;
        String services = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        return services != null && services.contains("com.sf2bot/.service.BotAccessibilityService");
    }

    private void showAccessibilityDialog() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("🥷 SF2 AI Bot")
            .setMessage("Cần bật 'SF2 Bot Service' trong:\nCài đặt → Trợ năng → Ứng dụng đã cài đặt → SF2 Bot Service → BẬT\n\nBot cần quyền này để điều khiển game.")
            .setPositiveButton("Mở Cài đặt", (d, w) ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
            .setNegativeButton("Hủy", null)
            .show();
    }

    private void requestMediaProjection() {
        // Yêu cầu quyền chụp màn hình
        startActivityForResult(
            projManager.createScreenCaptureIntent(),
            REQ_MEDIA_PROJ
        );
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_MEDIA_PROJ && res == RESULT_OK) {
            // Khởi động Foreground Service với MediaProjection
            Intent svc = new Intent(this, com.sf2bot.service.BotForegroundService.class);
            svc.putExtra("projection_data", data);
            svc.putExtra("projection_result", res);
            startForegroundService(svc);
            // Service sẽ gọi BotAccessibilityService.startBot()
            btnStart.setEnabled(false);
            btnStop.setEnabled(true);
            btnCalibrate.setEnabled(false);
            dotRunning.setVisibility(View.VISIBLE);
            layoutStats.setVisibility(View.VISIBLE);
            tvStatus.setText("🤖 Bot đang chạy...");
        }
    }

    private void stopBot() {
        BotAccessibilityService svc = BotAccessibilityService.getInstance();
        if (svc != null) svc.stopBot();
        stopService(new Intent(this, com.sf2bot.service.BotForegroundService.class));
        btnStart.setEnabled(true);
        btnStop.setEnabled(false);
        btnCalibrate.setEnabled(true);
        dotRunning.setVisibility(View.GONE);
        tvStatus.setText("⏹ Bot đã dừng");
    }

    private void startStatsUpdater() {
        statsUpdater = new Runnable() {
            @Override public void run() {
                updateStats();
                handler.postDelayed(this, 500); // update mỗi 500ms
            }
        };
        handler.post(statsUpdater);
    }

    private void updateStats() {
        BotAccessibilityService svc = BotAccessibilityService.getInstance();
        if (svc == null || !svc.isRunning()) return;

        SF2AIEngine ai = svc.getAIEngine();
        if (ai == null) return;

        String brainColor = switch (ai.getBrainState()) {
            case DODGING   -> "🛡️ DODGING";
            case PUNISHING -> "⚔️ PUNISHING";
            case COMBOING  -> "🥊 COMBOING";
            case RETREATING-> "💨 RETREATING";
            case THREAT    -> "⚠️ THREAT";
            default        -> "😐 NEUTRAL";
        };

        tvBrainState.setText(brainColor);
        tvDodges.setText("Dodge: " + ai.perfectDodges + " | Predicted: " + ai.predictedDodges);
        tvPunishes.setText("Punishes: " + ai.punishes);
        tvCombos.setText("Combos: " + ai.combosLanded);
        tvWinLoss.setText("W: " + svc.getWins() + "  L: " + svc.getLosses());
        tvStats.setText("Observations: " + ai.getPatternMemory().getTotalObservations()
                + " | Frames: " + ai.frameCount);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(statsUpdater);
        unregisterReceiver(serviceReadyReceiver);
    }
}
