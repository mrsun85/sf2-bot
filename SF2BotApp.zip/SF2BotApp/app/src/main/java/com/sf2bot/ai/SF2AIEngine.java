package com.sf2bot.ai;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║   SF2 AI ENGINE — Chạy 100% trên điện thoại                ║
 * ║                                                              ║
 * ║   Thuật toán:                                               ║
 * ║   1. Vision Processor  — phân tích bitmap frame             ║
 * ║   2. PatternMemory     — N-gram + Markov Chain              ║
 * ║   3. ReinforcementCore — Q-Learning đơn giản (online)       ║
 * ║   4. DodgeTable        — bảng né tối ưu per-action          ║
 * ║   5. PunishWindow      — theo dõi recovery frames           ║
 * ╚══════════════════════════════════════════════════════════════╝
 */
public class SF2AIEngine {

    private static final String TAG = "SF2AI";

    // ─── Enum hành động địch ───────────────────────────────────
    public enum EnemyAction {
        IDLE, WALK_FWD, WALK_BACK,
        PUNCH_LOW, PUNCH_MID, PUNCH_HIGH,
        KICK_LOW,  KICK_MID,  KICK_HIGH,
        JUMP_ATK,  JUMP_KICK,
        WEAPON_SLASH, WEAPON_THRUST,
        MAGIC_A, MAGIC_B, MAGIC_C,
        STAGGER, KNOCKDOWN, GETTING_UP
    }

    // ─── Enum hành động bot ────────────────────────────────────
    public enum BotAction {
        IDLE,
        PUNCH, KICK, JUMP_ATK,
        DODGE_BACK, DODGE_FWD,
        JUMP, CROUCH,
        BLOCK_HIGH, BLOCK_LOW,
        WEAPON, MAGIC,
        COMBO_PPK,   // Punch Punch Kick
        COMBO_KP     // Kick Punch
    }

    // ─── Trạng thái não bot ────────────────────────────────────
    public enum BrainState {
        NEUTRAL, THREAT, DODGING, PUNISHING, COMBOING, RETREATING
    }

    // ══════════════════════════════════════════════════════════
    //  GAME STATE snapshot
    // ══════════════════════════════════════════════════════════
    public static class GameSnapshot {
        public float playerHp;       // 0.0–1.0
        public float enemyHp;        // 0.0–1.0
        public float playerMana;
        public float distanceNorm;   // 0.0–1.0
        public float motionMag;      // magnitude chuyển động địch
        public float motionDx, motionDy;
        public float upperMotion, lowerMotion;
        public float accel;          // gia tốc đột ngột
        public boolean enemyAirborne;
        public boolean playerAirborne;
        public EnemyAction enemyAction;
        public long timestampMs;
        public int frameNumber;
    }

    // ══════════════════════════════════════════════════════════
    //  VISION PROCESSOR
    // ══════════════════════════════════════════════════════════
    public static class VisionProcessor {
        private final int screenW, screenH;
        private int[] prevPixels;
        private final List<Float> motionHistory = new ArrayList<>();

        // HP bar vùng (tỷ lệ)
        private static final float[] PLAYER_HP_ROI = {0.05f, 0.04f, 0.45f, 0.08f};
        private static final float[] ENEMY_HP_ROI  = {0.55f, 0.04f, 0.95f, 0.08f};
        private static final float[] MANA_ROI      = {0.05f, 0.09f, 0.35f, 0.12f};
        private static final float[] ENEMY_BODY_ROI= {0.40f, 0.15f, 0.95f, 0.85f};

        // Ngưỡng gia tốc để detect bắt đầu đòn
        private static final float ATTACK_ACCEL_THRESHOLD = 3.5f;
        private float prevMotionMag = 0f;

        public VisionProcessor(int w, int h) {
            this.screenW = w;
            this.screenH = h;
        }

        public GameSnapshot process(Bitmap frame, int frameNum) {
            GameSnapshot snap = new GameSnapshot();
            snap.timestampMs = System.currentTimeMillis();
            snap.frameNumber  = frameNum;

            int[] pixels = new int[frame.getWidth() * frame.getHeight()];
            frame.getPixels(pixels, 0, frame.getWidth(), 0, 0,
                            frame.getWidth(), frame.getHeight());

            snap.playerHp   = readBar(pixels, frame.getWidth(), frame.getHeight(),
                                      PLAYER_HP_ROI, "player");
            snap.enemyHp    = readBar(pixels, frame.getWidth(), frame.getHeight(),
                                      ENEMY_HP_ROI, "enemy");
            snap.playerMana = readBar(pixels, frame.getWidth(), frame.getHeight(),
                                      MANA_ROI, "mana");

            // Motion analysis
            MotionResult motion = analyzeMotion(pixels, frame.getWidth(), frame.getHeight());
            snap.motionMag   = motion.mag;
            snap.motionDx    = motion.dx;
            snap.motionDy    = motion.dy;
            snap.upperMotion = motion.upperMag;
            snap.lowerMotion = motion.lowerMag;
            snap.accel       = motion.mag - prevMotionMag;
            prevMotionMag    = motion.mag;

            snap.enemyAirborne = detectAirborne(pixels, frame.getWidth(), frame.getHeight(), false);
            snap.playerAirborne= detectAirborne(pixels, frame.getWidth(), frame.getHeight(), true);

            snap.enemyAction = classifyAction(snap);
            snap.distanceNorm= estimateDistance(pixels, frame.getWidth(), frame.getHeight());

            prevPixels = pixels.clone();
            return snap;
        }

        private float readBar(int[] pixels, int w, int h, float[] roi, String type) {
            int x1 = (int)(roi[0]*w), y1 = (int)(roi[1]*h);
            int x2 = (int)(roi[2]*w), y2 = (int)(roi[3]*h);
            int filled = 0, total = x2 - x1;
            for (int x = x1; x < x2; x++) {
                int idx = y1 * w + x;
                if (idx >= pixels.length) continue;
                int c = pixels[idx];
                int r = Color.red(c), g = Color.green(c), b = Color.blue(c);
                boolean match = switch (type) {
                    case "player" -> g > 120 && r < 100 && b < 100; // xanh lá
                    case "enemy"  -> r > 120 && g < 100 && b < 100; // đỏ
                    case "mana"   -> b > 120 && r < 100 && g < 100; // xanh dương
                    default -> false;
                };
                if (match) filled = x - x1 + 1;
            }
            return total > 0 ? Math.min(1f, (float)filled / total) : 1f;
        }

        private static class MotionResult {
            float mag, dx, dy, upperMag, lowerMag;
        }

        private MotionResult analyzeMotion(int[] curr, int w, int h) {
            MotionResult r = new MotionResult();
            if (prevPixels == null || prevPixels.length != curr.length) return r;

            int x1 = (int)(0.40f*w), y1 = (int)(0.15f*h);
            int x2 = (int)(0.95f*w), y2 = (int)(0.85f*h);
            int midY = (y1 + y2) / 2;

            float totalDiff = 0, upperDiff = 0, lowerDiff = 0;
            float sumDx = 0, sumDy = 0;
            int count = 0;

            for (int y = y1; y < y2; y += 3) {
                for (int x = x1; x < x2; x += 3) {
                    int idx = y * w + x;
                    if (idx >= curr.length) continue;
                    int diff = Math.abs(luminance(curr[idx]) - luminance(prevPixels[idx]));
                    totalDiff += diff;
                    if (y < midY) upperDiff += diff;
                    else          lowerDiff += diff;
                    count++;
                }
            }
            if (count == 0) return r;

            r.mag      = totalDiff / count / 255f * 20f; // 0–20 scale
            r.upperMag = upperDiff / Math.max(count/2f, 1) / 255f * 20f;
            r.lowerMag = lowerDiff / Math.max(count/2f, 1) / 255f * 20f;
            // Simple dx/dy từ brightness gradient
            r.dx = estimateFlowX(curr, prevPixels, w, h, x1, y1, x2, y2);
            r.dy = estimateFlowY(curr, prevPixels, w, h, x1, y1, x2, y2);
            return r;
        }

        private float estimateFlowX(int[] a, int[] b, int w, int h,
                                     int x1, int y1, int x2, int y2) {
            float leftDiff = 0, rightDiff = 0;
            int midX = (x1+x2)/2;
            for (int y = y1; y < y2; y += 4) {
                for (int x = x1; x < midX; x += 4) {
                    int idx = y*w+x;
                    if (idx < a.length) leftDiff += Math.abs(luminance(a[idx])-luminance(b[idx]));
                }
                for (int x = midX; x < x2; x += 4) {
                    int idx = y*w+x;
                    if (idx < a.length) rightDiff += Math.abs(luminance(a[idx])-luminance(b[idx]));
                }
            }
            return (rightDiff - leftDiff) / 255f * 5f;
        }

        private float estimateFlowY(int[] a, int[] b, int w, int h,
                                     int x1, int y1, int x2, int y2) {
            float topDiff = 0, botDiff = 0;
            int midY = (y1+y2)/2;
            for (int x = x1; x < x2; x += 4) {
                for (int y = y1; y < midY; y += 4) {
                    int idx = y*w+x;
                    if (idx < a.length) topDiff += Math.abs(luminance(a[idx])-luminance(b[idx]));
                }
                for (int y = midY; y < y2; y += 4) {
                    int idx = y*w+x;
                    if (idx < a.length) botDiff += Math.abs(luminance(a[idx])-luminance(b[idx]));
                }
            }
            return (botDiff - topDiff) / 255f * 5f;
        }

        private boolean detectAirborne(int[] pixels, int w, int h, boolean isPlayer) {
            // Tìm bóng đen ở vùng floor (y > 75%)
            int x1 = isPlayer ? 0 : w/2;
            int x2 = isPlayer ? w/2 : w;
            int floorY = (int)(0.75f * h);
            int arenaY = (int)(0.50f * h);
            int darkPixelsFloor = 0, darkPixelsArena = 0;
            for (int x = x1; x < x2; x += 5) {
                for (int y = floorY; y < h; y += 5) {
                    int idx = y*w+x;
                    if (idx < pixels.length && luminance(pixels[idx]) < 40) darkPixelsFloor++;
                }
                for (int y = arenaY; y < floorY; y += 5) {
                    int idx = y*w+x;
                    if (idx < pixels.length && luminance(pixels[idx]) < 40) darkPixelsArena++;
                }
            }
            // Nếu bóng tối chủ yếu ở giữa màn hình thay vì dưới → đang nhảy
            return darkPixelsArena > darkPixelsFloor * 1.5f && darkPixelsArena > 10;
        }

        private float estimateDistance(int[] pixels, int w, int h) {
            // Tìm trung tâm X của bóng player và enemy
            float playerX = findSilhouetteCenterX(pixels, w, h, 0, w/2);
            float enemyX  = findSilhouetteCenterX(pixels, w, h, w/2, w);
            return Math.abs(enemyX - playerX) / w;
        }

        private float findSilhouetteCenterX(int[] pixels, int w, int h,
                                              int x1, int x2) {
            int arenaTop = (int)(0.15f*h), arenaBot = (int)(0.90f*h);
            float sumX = 0; int count = 0;
            for (int x = x1; x < x2; x += 4) {
                for (int y = arenaTop; y < arenaBot; y += 4) {
                    int idx = y*w+x;
                    if (idx < pixels.length && luminance(pixels[idx]) < 40) {
                        sumX += x; count++;
                    }
                }
            }
            return count > 0 ? sumX/count : (x1+x2)/2f;
        }

        private EnemyAction classifyAction(GameSnapshot s) {
            if (s.enemyAirborne) {
                return s.lowerMotion > s.upperMotion * 1.3f
                        ? EnemyAction.JUMP_KICK : EnemyAction.JUMP_ATK;
            }
            if (s.motionMag < 0.5f) return EnemyAction.IDLE;
            if (s.motionMag < 1.5f) {
                return s.motionDx < -0.3f ? EnemyAction.WALK_FWD :
                       s.motionDx >  0.3f ? EnemyAction.WALK_BACK : EnemyAction.IDLE;
            }
            if (s.accel > ATTACK_ACCEL_THRESHOLD) {
                // Đột ngột tăng tốc → bắt đầu đòn
                if (s.upperMotion > s.lowerMotion * 1.4f) {
                    if (s.motionDy < -0.8f) return EnemyAction.PUNCH_HIGH;
                    if (s.motionDy >  0.8f) return EnemyAction.PUNCH_LOW;
                    return EnemyAction.PUNCH_MID;
                } else {
                    if (s.motionDy < -0.8f) return EnemyAction.KICK_HIGH;
                    if (s.motionDy >  0.8f) return EnemyAction.KICK_LOW;
                    return EnemyAction.KICK_MID;
                }
            }
            if (s.motionMag > 8f) {
                return Math.abs(s.motionDx) > Math.abs(s.motionDy)*1.5f
                        ? EnemyAction.WEAPON_SLASH : EnemyAction.WEAPON_THRUST;
            }
            if (s.motionMag > 5f) {
                return s.upperMotion > s.lowerMotion ? EnemyAction.PUNCH_MID : EnemyAction.KICK_MID;
            }
            return EnemyAction.IDLE;
        }

        private int luminance(int color) {
            return (Color.red(color)*30 + Color.green(color)*59 + Color.blue(color)*11) / 100;
        }
    }

    // ══════════════════════════════════════════════════════════
    //  PATTERN MEMORY (N-gram online learning)
    // ══════════════════════════════════════════════════════════
    public static class PatternMemory {
        private static final int N = 3;
        private final Deque<EnemyAction> history = new ArrayDeque<>(20);
        // key = "A,B" → {next_action → count}
        private final Map<String, Map<EnemyAction, Integer>> ngram = new HashMap<>();
        private int totalObservations = 0;

        public void observe(EnemyAction action) {
            history.addLast(action);
            if (history.size() > 20) history.pollFirst();
            totalObservations++;

            List<EnemyAction> hist = new ArrayList<>(history);
            if (hist.size() >= N) {
                String key = buildKey(hist.subList(hist.size()-N, hist.size()-1));
                ngram.computeIfAbsent(key, k -> new HashMap<>())
                     .merge(action, 1, Integer::sum);
            }
            // Bigram cũng học
            if (hist.size() >= 2) {
                String key2 = buildKey(hist.subList(hist.size()-2, hist.size()-1));
                ngram.computeIfAbsent(key2, k -> new HashMap<>())
                     .merge(action, 1, Integer::sum);
            }
        }

        public EnemyAction predictNext() {
            if (history.size() < 2) return null;
            List<EnemyAction> hist = new ArrayList<>(history);

            // Thử N-gram trước
            if (hist.size() >= N-1) {
                String key = buildKey(hist.subList(hist.size()-(N-1), hist.size()));
                EnemyAction pred = bestFromDist(key);
                if (pred != null) return pred;
            }
            // Fallback bigram
            String key2 = hist.get(hist.size()-1).name();
            return bestFromDist(key2);
        }

        private EnemyAction bestFromDist(String key) {
            Map<EnemyAction, Integer> dist = ngram.get(key);
            if (dist == null || dist.isEmpty()) return null;
            int total = dist.values().stream().mapToInt(i->i).sum();
            EnemyAction best = null; int bestCnt = 0;
            for (Map.Entry<EnemyAction,Integer> e : dist.entrySet()) {
                if (e.getValue() > bestCnt) { bestCnt = e.getValue(); best = e.getKey(); }
            }
            float confidence = bestCnt / (float)total;
            return confidence >= 0.30f ? best : null;
        }

        private String buildKey(List<EnemyAction> actions) {
            StringBuilder sb = new StringBuilder();
            for (EnemyAction a : actions) { if (sb.length()>0) sb.append(','); sb.append(a.name()); }
            return sb.toString();
        }

        public int getTotalObservations() { return totalObservations; }

        // Serialize để lưu
        public Map<String, Object> serialize() {
            Map<String, Object> out = new HashMap<>();
            out.put("total", totalObservations);
            Map<String, Map<String, Integer>> strMap = new HashMap<>();
            for (Map.Entry<String, Map<EnemyAction,Integer>> e : ngram.entrySet()) {
                Map<String,Integer> inner = new HashMap<>();
                for (Map.Entry<EnemyAction,Integer> ie : e.getValue().entrySet())
                    inner.put(ie.getKey().name(), ie.getValue());
                strMap.put(e.getKey(), inner);
            }
            out.put("ngram", strMap);
            return out;
        }
    }

    // ══════════════════════════════════════════════════════════
    //  Q-LEARNING CORE (Online Reinforcement Learning)
    // ══════════════════════════════════════════════════════════
    public static class QLearningCore {
        private static final float ALPHA   = 0.15f;  // learning rate
        private static final float GAMMA   = 0.90f;  // discount factor
        private static final float EPSILON = 0.10f;  // exploration rate (10% random)

        // Q-table: state_key → {action → q_value}
        private final Map<String, Map<BotAction, Float>> qTable = new HashMap<>();
        private final Random rand = new Random();

        // Phần thưởng
        private static final float REWARD_DODGE_SUCCESS  =  2.0f;
        private static final float REWARD_PUNISH_SUCCESS =  1.5f;
        private static final float REWARD_COMBO_HIT      =  1.0f;
        private static final float PENALTY_HIT_TAKEN     = -3.0f;
        private static final float PENALTY_WRONG_DODGE   = -1.0f;

        private String lastStateKey;
        private BotAction lastAction;
        private float prevPlayerHp = 1.0f;
        private float prevEnemyHp  = 1.0f;

        public BotAction selectAction(String stateKey, List<BotAction> validActions) {
            // Epsilon-greedy
            if (rand.nextFloat() < EPSILON) {
                return validActions.get(rand.nextInt(validActions.size()));
            }
            Map<BotAction, Float> values = qTable.getOrDefault(stateKey, new HashMap<>());
            BotAction best = null; float bestQ = Float.NEGATIVE_INFINITY;
            for (BotAction a : validActions) {
                float q = values.getOrDefault(a, 0f);
                if (q > bestQ) { bestQ = q; best = a; }
            }
            return best != null ? best : validActions.get(rand.nextInt(validActions.size()));
        }

        public void update(GameSnapshot curr, BotAction actionTaken) {
            if (lastStateKey == null || lastAction == null) {
                lastStateKey = buildStateKey(curr);
                lastAction   = actionTaken;
                prevPlayerHp = curr.playerHp;
                prevEnemyHp  = curr.enemyHp;
                return;
            }
            // Tính reward
            float reward = 0f;
            float hpDelta    = curr.playerHp - prevPlayerHp;
            float enemyDelta = curr.enemyHp  - prevEnemyHp;

            if (hpDelta < -0.01f)   reward += PENALTY_HIT_TAKEN * (-hpDelta * 10f);
            if (enemyDelta < -0.01f) reward += REWARD_COMBO_HIT * (-enemyDelta * 10f);
            // Bonus nếu vừa né thành công (HP không giảm mặc dù địch tấn công)
            if (lastAction == BotAction.DODGE_BACK || lastAction == BotAction.DODGE_FWD
                    || lastAction == BotAction.JUMP || lastAction == BotAction.CROUCH) {
                if (hpDelta >= 0f) reward += REWARD_DODGE_SUCCESS;
                else               reward += PENALTY_WRONG_DODGE;
            }

            // Q-update
            String newKey = buildStateKey(curr);
            Map<BotAction, Float> oldValues = qTable.computeIfAbsent(lastStateKey, k -> new HashMap<>());
            Map<BotAction, Float> newValues = qTable.getOrDefault(newKey, new HashMap<>());
            float maxNextQ = newValues.isEmpty() ? 0f :
                    Collections.max(newValues.values());
            float oldQ = oldValues.getOrDefault(lastAction, 0f);
            float newQ = oldQ + ALPHA * (reward + GAMMA * maxNextQ - oldQ);
            oldValues.put(lastAction, newQ);

            lastStateKey = newKey;
            lastAction   = actionTaken;
            prevPlayerHp = curr.playerHp;
            prevEnemyHp  = curr.enemyHp;
        }

        private String buildStateKey(GameSnapshot s) {
            // Discretize state thành bucket để Q-table không quá lớn
            int hpBucket   = (int)(s.playerHp * 4);   // 0,1,2,3,4
            int distBucket = (int)(s.distanceNorm * 5);// 0-5
            int motBucket  = s.motionMag > 5f ? 2 : s.motionMag > 1.5f ? 1 : 0;
            return s.enemyAction.name() + "_" + hpBucket + "_" + distBucket
                   + "_" + motBucket + "_" + (s.enemyAirborne ? "A" : "G");
        }

        public Map<String, Map<BotAction, Float>> getQTable() { return qTable; }
    }

    // ══════════════════════════════════════════════════════════
    //  DODGE TABLE — né tối ưu hard-coded làm baseline
    // ══════════════════════════════════════════════════════════
    private static final Map<EnemyAction, List<BotAction>> DODGE_TABLE;
    static {
        DODGE_TABLE = new EnumMap<>(EnemyAction.class);
        DODGE_TABLE.put(EnemyAction.PUNCH_LOW,     Arrays.asList(BotAction.JUMP,       BotAction.BLOCK_LOW));
        DODGE_TABLE.put(EnemyAction.PUNCH_MID,     Arrays.asList(BotAction.DODGE_BACK, BotAction.BLOCK_HIGH));
        DODGE_TABLE.put(EnemyAction.PUNCH_HIGH,    Arrays.asList(BotAction.CROUCH,     BotAction.BLOCK_HIGH));
        DODGE_TABLE.put(EnemyAction.KICK_LOW,      Arrays.asList(BotAction.JUMP,       BotAction.BLOCK_LOW));
        DODGE_TABLE.put(EnemyAction.KICK_MID,      Arrays.asList(BotAction.DODGE_BACK, BotAction.BLOCK_HIGH));
        DODGE_TABLE.put(EnemyAction.KICK_HIGH,     Arrays.asList(BotAction.CROUCH,     BotAction.DODGE_BACK));
        DODGE_TABLE.put(EnemyAction.JUMP_ATK,      Arrays.asList(BotAction.DODGE_BACK, BotAction.BLOCK_HIGH));
        DODGE_TABLE.put(EnemyAction.JUMP_KICK,     Arrays.asList(BotAction.DODGE_BACK, BotAction.CROUCH));
        DODGE_TABLE.put(EnemyAction.WEAPON_SLASH,  Arrays.asList(BotAction.DODGE_BACK, BotAction.JUMP));
        DODGE_TABLE.put(EnemyAction.WEAPON_THRUST, Arrays.asList(BotAction.JUMP,       BotAction.DODGE_BACK));
        DODGE_TABLE.put(EnemyAction.MAGIC_A,       Arrays.asList(BotAction.DODGE_BACK, BotAction.JUMP));
        DODGE_TABLE.put(EnemyAction.MAGIC_B,       Arrays.asList(BotAction.JUMP,       BotAction.DODGE_BACK));
        DODGE_TABLE.put(EnemyAction.MAGIC_C,       Arrays.asList(BotAction.DODGE_FWD,  BotAction.JUMP));
    }

    // Recovery frames kẻ địch (để tính punishment window)
    private static final Map<EnemyAction, Integer> RECOVERY_FRAMES;
    static {
        RECOVERY_FRAMES = new EnumMap<>(EnemyAction.class);
        RECOVERY_FRAMES.put(EnemyAction.PUNCH_LOW,     4);
        RECOVERY_FRAMES.put(EnemyAction.PUNCH_MID,     5);
        RECOVERY_FRAMES.put(EnemyAction.PUNCH_HIGH,    5);
        RECOVERY_FRAMES.put(EnemyAction.KICK_LOW,      6);
        RECOVERY_FRAMES.put(EnemyAction.KICK_MID,      7);
        RECOVERY_FRAMES.put(EnemyAction.KICK_HIGH,     8);
        RECOVERY_FRAMES.put(EnemyAction.WEAPON_SLASH,  9);
        RECOVERY_FRAMES.put(EnemyAction.WEAPON_THRUST, 10);
        RECOVERY_FRAMES.put(EnemyAction.MAGIC_A,       12);
        RECOVERY_FRAMES.put(EnemyAction.MAGIC_B,       14);
        RECOVERY_FRAMES.put(EnemyAction.MAGIC_C,       18);
        RECOVERY_FRAMES.put(EnemyAction.JUMP_ATK,      6);
        RECOVERY_FRAMES.put(EnemyAction.JUMP_KICK,     7);
    }

    // ══════════════════════════════════════════════════════════
    //  MASTER DECISION PIPELINE
    // ══════════════════════════════════════════════════════════
    private final VisionProcessor vision;
    private final PatternMemory   patternMemory;
    private final QLearningCore   qLearning;
    private BrainState brainState = BrainState.NEUTRAL;

    // Punishment window
    private long punishWindowEndMs = 0;
    private EnemyAction lastEnemyAttack = null;

    // Cooldown
    private long lastActionMs = 0;
    private static final long ACTION_COOLDOWN_MS = 120;

    // Combo queue
    private final Deque<BotAction> comboQueue = new ArrayDeque<>();

    // Stats
    public int perfectDodges = 0, predictedDodges = 0;
    public int punishes = 0, combosLanded = 0, frameCount = 0;
    public float totalDamageTaken = 0f;

    public SF2AIEngine(int screenW, int screenH) {
        this.vision        = new VisionProcessor(screenW, screenH);
        this.patternMemory = new PatternMemory();
        this.qLearning     = new QLearningCore();
    }

    /**
     * Điểm vào chính: nhận Bitmap → trả về BotAction
     */
    public BotAction processFrame(Bitmap frame) {
        frameCount++;
        GameSnapshot snap = vision.process(frame, frameCount);
        patternMemory.observe(snap.enemyAction);
        qLearning.update(snap, BotAction.IDLE);

        long now = System.currentTimeMillis();
        if (now - lastActionMs < ACTION_COOLDOWN_MS) return BotAction.IDLE;

        BotAction decision = decisionPipeline(snap, now);
        if (decision != BotAction.IDLE) {
            qLearning.update(snap, decision);
            lastActionMs = now;
        }
        return decision;
    }

    private BotAction decisionPipeline(GameSnapshot s, long now) {

        // 1. Combo đang dở
        if (!comboQueue.isEmpty()) {
            BotAction next = comboQueue.poll();
            if (isAttacking(s.enemyAction)) comboQueue.clear();
            else return next;
        }

        // 2. Detect startup frame → né ngay (PHÒNG THỦ 1)
        if (s.accel > 3.5f && isAttacking(s.enemyAction)) {
            recordEnemyAttack(s.enemyAction, now);
            BotAction dodge = getOptimalDodge(s);
            if (dodge != null) {
                perfectDodges++;
                brainState = BrainState.DODGING;
                Log.d(TAG, "🛡️ PERFECT DODGE: " + s.enemyAction + " → " + dodge);
                return dodge;
            }
        }

        // 3. Pattern prediction → né trước (PHÒNG THỦ 2)
        EnemyAction predicted = patternMemory.predictNext();
        if (predicted != null && isAttacking(predicted) && s.distanceNorm < 0.35f
                && (s.enemyAction == EnemyAction.IDLE || s.enemyAction == EnemyAction.WALK_FWD)) {
            BotAction dodge = getOptimalDodge(s.enemyAction != EnemyAction.IDLE
                    ? s : makeSnapshotWith(s, predicted));
            if (dodge != null) {
                predictedDodges++;
                brainState = BrainState.THREAT;
                Log.d(TAG, "🔮 PREDICTED DODGE: " + predicted + " → " + dodge);
                return dodge;
            }
        }

        // 4. Punishment window → phản công
        if (now < punishWindowEndMs && lastEnemyAttack != null) {
            punishes++;
            brainState = BrainState.PUNISHING;
            if (s.distanceNorm < 0.20f) {
                startCombo("PPK"); // Punch Punch Kick
                return comboQueue.poll();
            }
            return s.distanceNorm < 0.35f ? BotAction.PUNCH : BotAction.DODGE_FWD;
        }

        // 5. Retreat nếu HP nguy hiểm
        if (s.playerHp < 0.25f && s.distanceNorm < 0.30f) {
            brainState = BrainState.RETREATING;
            return BotAction.DODGE_BACK;
        }

        // 6. Q-Learning chọn đòn tấn công
        if (s.enemyAction == EnemyAction.IDLE || s.enemyAction == EnemyAction.STAGGER
                || s.enemyAction == EnemyAction.KNOCKDOWN) {
            brainState = BrainState.COMBOING;
            return qLearningAttack(s);
        }

        // 7. Tiến lên nếu xa
        if (s.distanceNorm > 0.55f) return BotAction.DODGE_FWD;

        return BotAction.IDLE;
    }

    private BotAction getOptimalDodge(GameSnapshot s) {
        return getOptimalDodge(s.enemyAction);
    }

    private BotAction getOptimalDodge(EnemyAction action) {
        List<BotAction> options = DODGE_TABLE.get(action);
        if (options == null || options.isEmpty()) return null;
        return options.get(0); // luôn lấy lựa chọn tốt nhất
    }

    private void recordEnemyAttack(EnemyAction action, long now) {
        lastEnemyAttack = action;
        int recoveryFrames = RECOVERY_FRAMES.getOrDefault(action, 5);
        punishWindowEndMs = now + (long)(recoveryFrames * 1000f / 15f); // 15fps
    }

    private BotAction qLearningAttack(GameSnapshot s) {
        String key = s.enemyAction.name() + "_" +
                     (int)(s.distanceNorm*5) + "_" +
                     (int)(s.playerHp*4);
        List<BotAction> attackOptions = Arrays.asList(
                BotAction.PUNCH, BotAction.KICK,
                BotAction.COMBO_PPK, BotAction.COMBO_KP, BotAction.JUMP_ATK
        );
        BotAction chosen = qLearning.selectAction(key, attackOptions);
        if (chosen == BotAction.COMBO_PPK) {
            startCombo("PPK");
            combosLanded++;
            return comboQueue.poll();
        }
        return chosen;
    }

    private void startCombo(String type) {
        comboQueue.clear();
        if ("PPK".equals(type)) {
            comboQueue.add(BotAction.PUNCH);
            comboQueue.add(BotAction.PUNCH);
            comboQueue.add(BotAction.KICK);
        } else if ("KP".equals(type)) {
            comboQueue.add(BotAction.KICK);
            comboQueue.add(BotAction.PUNCH);
        }
    }

    private boolean isAttacking(EnemyAction a) {
        return a != EnemyAction.IDLE && a != EnemyAction.WALK_FWD
            && a != EnemyAction.WALK_BACK && a != EnemyAction.STAGGER
            && a != EnemyAction.KNOCKDOWN && a != EnemyAction.GETTING_UP;
    }

    private GameSnapshot makeSnapshotWith(GameSnapshot orig, EnemyAction overrideAction) {
        GameSnapshot copy = new GameSnapshot();
        copy.playerHp = orig.playerHp; copy.enemyHp = orig.enemyHp;
        copy.distanceNorm = orig.distanceNorm; copy.enemyAirborne = orig.enemyAirborne;
        copy.playerAirborne = orig.playerAirborne; copy.motionMag = orig.motionMag;
        copy.enemyAction = overrideAction;
        return copy;
    }

    public BrainState getBrainState()    { return brainState; }
    public PatternMemory getPatternMemory() { return patternMemory; }
    public QLearningCore getQLearning()  { return qLearning; }

    public String getStatsSummary() {
        return String.format(
            "Frames:%d | Observations:%d | Dodges:%d | Predicted:%d | Punishes:%d | Combos:%d",
            frameCount, patternMemory.getTotalObservations(),
            perfectDodges, predictedDodges, punishes, combosLanded
        );
    }
}
