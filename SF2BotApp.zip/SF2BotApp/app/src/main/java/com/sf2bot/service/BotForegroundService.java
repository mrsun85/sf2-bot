package com.sf2bot.service;

import android.app.*;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import com.sf2bot.R;
import com.sf2bot.ui.MainActivity;

/**
 * Foreground Service:
 * - Hiển thị notification để Android không kill process
 * - Giữ WakeLock để màn hình tắt bot vẫn chạy
 * - Quản lý MediaProjection lifecycle
 */
public class BotForegroundService extends Service {

    private static final String TAG     = "SF2FgService";
    private static final String CHANNEL = "sf2bot_channel";
    private static final int    NOTIF_ID= 1;

    private PowerManager.WakeLock wakeLock;
    private MediaProjection mediaProjection;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification("🤖 SF2 AI Bot đang chạy..."));
        acquireWakeLock();
        Log.i(TAG, "ForegroundService started");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        int resultCode = intent.getIntExtra("projection_result", -1);
        Intent projData= intent.getParcelableExtra("projection_data");

        if (resultCode != -1 && projData != null) {
            MediaProjectionManager mgr = (MediaProjectionManager)
                    getSystemService(MEDIA_PROJECTION_SERVICE);
            mediaProjection = mgr.getMediaProjection(resultCode, projData);

            // Truyền cho Accessibility Service
            BotAccessibilityService svc = BotAccessibilityService.getInstance();
            if (svc != null) {
                svc.startBot(mediaProjection);
                updateNotification("🤖 Bot đang học... Để bot chạy liên tục!");
            } else {
                Log.e(TAG, "Accessibility Service chưa sẵn sàng!");
                stopSelf();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseWakeLock();
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        Log.i(TAG, "ForegroundService destroyed");
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SF2Bot::BotWakeLock"
        );
        wakeLock.acquire(); // Không có timeout = chạy mãi đến khi release
        Log.i(TAG, "WakeLock acquired");
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            wakeLock = null;
            Log.i(TAG, "WakeLock released");
        }
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL, "SF2 Bot", NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("SF2 AI Bot đang chạy nền");
        channel.setSound(null, null);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, mainIntent,
                PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, BotForegroundService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("🥷 SF2 AI Bot")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Dừng Bot", stopPi)
            .build();
    }

    private void updateNotification(String text) {
        getSystemService(NotificationManager.class)
            .notify(NOTIF_ID, buildNotification(text));
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
