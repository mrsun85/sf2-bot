package com.sf2bot.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

import com.sf2bot.ai.SF2AIEngine;
import com.sf2bot.ai.SF2AIEngine.BotAction;
import com.sf2bot.utils.BotConfig;
import com.sf2bot.utils.DataSaver;

import java.nio.ByteBuffer;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Accessibility Service chính:
 * - Nhận MediaProjection để chụp màn hình
 * - Phân tích frame qua SF2AIEngine
 * - Inject gesture (tap/swipe) để điều khiển game
 * - Chạy trong foreground service, không cần root
 */
public class BotAccessibilityService extends AccessibilityService {

    private static final String TAG = "SF2BotService";
    private static BotAccessibilityService instance;

    private SF2AIEngine aiEngine;
    private BotConfig config;
    private DataSaver dataSaver;

    // Screen capture
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int screenW, screenH, screenDensity;

    // Loop
    private ScheduledExecutorService executor;
    private final AtomicBoolean isRunning = new AtomicBoolean(false);
    private static final int TARGET_FPS = 15;

    // Stats
    private int wins = 0, losses = 0;
    private long sessionStartMs;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // ─────────────────────────────────────────────────────────
    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.i(TAG, "✅ Accessibility Service kết nối");

        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager)getSystemService(WINDOW_SERVICE))
                .getDefaultDisplay().getRealMetrics(metrics);
        screenW       = metrics.widthPixels;
        screenH       = metrics.heightPixels;
        screenDensity = metrics.densityDpi;

        config    = BotConfig.load(this);
        dataSaver = new DataSaver(this);
        aiEngine  = new SF2AIEngine(screenW, screenH);

        // Restore learned patterns nếu có
        dataSaver.loadPatterns(aiEngine);

        Log.i(TAG, "📱 Màn hình: " + screenW + "×" + screenH);
        sendBroadcast(new Intent("com.sf2bot.SERVICE_READY"));
    }

    // ─────────────────────────────────────────────────────────
    public static BotAccessibilityService getInstance() { return instance; }

    /** Gọi từ MainActivity sau khi có MediaProjection */
    public void startBot(MediaProjection projection) {
        if (isRunning.get()) return;
        this.mediaProjection = projection;
        setupCapture();
        sessionStartMs = System.currentTimeMillis();
        isRunning.set(true);

        executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(
            this::botTick,
            100,
            1000L / TARGET_FPS,  // ~66ms
            TimeUnit.MILLISECONDS
        );
        Log.i(TAG, "🚀 Bot bắt đầu chạy @ " + TARGET_FPS + " FPS");
    }

    public void stopBot() {
        isRunning.set(false);
        if (executor != null) { executor.shutdownNow(); executor = null; }
        releaseCapture();
        dataSaver.saveAll(aiEngine); // Lưu data học
        Log.i(TAG, "⛔ Bot dừng. W=" + wins + " L=" + losses);
    }

    // ─────────────────────────────────────────────────────────
    private void setupCapture() {
        imageReader = ImageReader.newInstance(
            screenW, screenH, PixelFormat.RGBA_8888, 2
        );
        virtualDisplay = mediaProjection.createVirtualDisplay(
            "SF2BotCapture",
            screenW, screenH, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(),
            null, null
        );
        Log.i(TAG, "📸 VirtualDisplay tạo xong");
    }

    private void releaseCapture() {
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader    != null) { imageReader.close();       imageReader    = null; }
        if (mediaProjection!= null) { mediaProjection.stop();    mediaProjection= null; }
    }

    // ─────────────────────────────────────────────────────────
    private void botTick() {
        if (!isRunning.get()) return;
        try {
            Bitmap frame = captureFrame();
            if (frame == null) return;

            BotAction action = aiEngine.processFrame(frame);
            frame.recycle();

            if (action != BotAction.IDLE) {
                executeAction(action);
            }

            // Auto-save mỗi 5 phút
            long elapsed = System.currentTimeMillis() - sessionStartMs;
            if (elapsed % (5 * 60 * 1000) < 200) {
                dataSaver.saveAll(aiEngine);
            }

        } catch (Exception e) {
            Log.e(TAG, "botTick error: " + e.getMessage());
        }
    }

    private Bitmap captureFrame() {
        if (imageReader == null) return null;
        Image image = imageReader.acquireLatestImage();
        if (image == null) return null;
        try {
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer    = planes[0].getBuffer();
            int pixelStride      = planes[0].getPixelStride();
            int rowStride        = planes[0].getRowStride();
            int rowPadding       = rowStride - pixelStride * screenW;

            Bitmap bmp = Bitmap.createBitmap(
                screenW + rowPadding/pixelStride, screenH, Bitmap.Config.ARGB_8888
            );
            bmp.copyPixelsFromBuffer(buffer);
            // Crop về đúng kích thước
            return Bitmap.createBitmap(bmp, 0, 0, screenW, screenH);
        } finally {
            image.close();
        }
    }

    // ─────────────────────────────────────────────────────────
    //  GESTURE EXECUTOR
    // ─────────────────────────────────────────────────────────
    private void executeAction(BotAction action) {
        switch (action) {
            case PUNCH       -> tap(config.punchX,  config.punchY,  80);
            case KICK        -> tap(config.kickX,   config.kickY,   80);
            case JUMP        -> tap(config.jumpX,   config.jumpY,   80);
            case CROUCH      -> swipe(config.moveLeftX, config.moveLeftY,
                                      config.moveLeftX, config.moveLeftY + 90, 60);
            case BLOCK_HIGH  -> tap(config.blockX,  config.blockY,  200);
            case BLOCK_LOW   -> tap(config.blockX,  config.blockY + 60, 200);
            case DODGE_BACK  -> swipe(config.moveLeftX,  config.moveLeftY,
                                      config.moveLeftX - 150, config.moveLeftY, 55);
            case DODGE_FWD   -> swipe(config.moveRightX, config.moveRightY,
                                      config.moveRightX + 150, config.moveRightY, 55);
            case WEAPON      -> tap(config.weaponX, config.weaponY,  80);
            case MAGIC       -> tap(config.magicX,  config.magicY,   80);
            case JUMP_ATK    -> {
                tap(config.jumpX, config.jumpY, 80);
                mainHandler.postDelayed(() -> tap(config.punchX, config.punchY, 80), 150);
            }
            case COMBO_PPK   -> {
                tap(config.punchX, config.punchY, 80);
                mainHandler.postDelayed(() -> tap(config.punchX, config.punchY, 80), 130);
                mainHandler.postDelayed(() -> tap(config.kickX,  config.kickY,  80), 260);
            }
            case COMBO_KP    -> {
                tap(config.kickX,  config.kickY,  80);
                mainHandler.postDelayed(() -> tap(config.punchX, config.punchY, 80), 150);
            }
        }
    }

    /** Inject tap gesture */
    private void tap(int x, int y, int durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);
    }

    /** Inject swipe gesture */
    private void swipe(int x1, int y1, int x2, int y2, int durationMs) {
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);
    }

    // ─────────────────────────────────────────────────────────
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted");
        stopBot();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopBot();
        instance = null;
    }

    // Getters cho UI
    public boolean isRunning() { return isRunning.get(); }
    public SF2AIEngine getAIEngine() { return aiEngine; }
    public int getWins()   { return wins; }
    public int getLosses() { return losses; }
    public void incrementWins()   { wins++; }
    public void incrementLosses() { losses++; }
}
