package com.sf2bot.ui;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import com.sf2bot.R;
import com.sf2bot.utils.BotConfig;

/**
 * Màn hình Calibrate:
 * - Hiển thị overlay trong suốt lên toàn màn hình
 * - Người dùng chạm vào đúng vị trí từng nút SF2
 * - Tự động lưu tọa độ
 */
public class CalibrateActivity extends Activity {

    private static final String[] BUTTON_NAMES = {
        "DI CHUYỂN TRÁI", "DI CHUYỂN PHẢI",
        "ĐÁNH / ĐẤM", "ĐÁ",
        "NHẢY", "BLOCK / ĐỠ",
        "VŨ KHÍ", "MAGIC"
    };
    private static final int[] BUTTON_COLORS = {
        0xFF2196F3, 0xFF2196F3,
        0xFFF44336, 0xFFF44336,
        0xFFFFEB3B, 0xFF4CAF50,
        0xFF9C27B0, 0xFF9C27B0
    };

    private int currentStep = 0;
    private final int[] savedX = new int[8];
    private final int[] savedY = new int[8];
    private BotConfig config;
    private CalibrateTouchView touchView;
    private TextView tvInstruction;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Fullscreen không có title bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_calibrate);

        config       = BotConfig.load(this);
        touchView    = findViewById(R.id.calibrateTouchView);
        tvInstruction= findViewById(R.id.tvInstruction);
        progressBar  = findViewById(R.id.progressCalibrate);

        progressBar.setMax(BUTTON_NAMES.length);
        updateInstruction();

        touchView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                onButtonTapped((int) event.getRawX(), (int) event.getRawY());
                return true;
            }
            return false;
        });

        // Nút bỏ qua
        Button btnSkip = findViewById(R.id.btnSkip);
        btnSkip.setOnClickListener(v -> {
            if (currentStep < BUTTON_NAMES.length - 1) {
                currentStep++;
                updateInstruction();
            }
        });
    }

    private void onButtonTapped(int x, int y) {
        savedX[currentStep] = x;
        savedY[currentStep] = y;
        touchView.addMark(x, y, BUTTON_COLORS[currentStep], BUTTON_NAMES[currentStep]);
        currentStep++;
        progressBar.setProgress(currentStep);

        if (currentStep >= BUTTON_NAMES.length) {
            saveConfig();
            finish();
            Toast.makeText(this, "✅ Calibration xong!", Toast.LENGTH_LONG).show();
        } else {
            updateInstruction();
        }
    }

    private void updateInstruction() {
        if (currentStep < BUTTON_NAMES.length) {
            tvInstruction.setText("(" + (currentStep+1) + "/" + BUTTON_NAMES.length + ") "
                    + "Chạm vào nút: " + BUTTON_NAMES[currentStep]);
            tvInstruction.setTextColor(BUTTON_COLORS[currentStep]);
        }
    }

    private void saveConfig() {
        // Map chỉ số sang trường BotConfig
        config.moveLeftX  = savedX[0]; config.moveLeftY  = savedY[0];
        config.moveRightX = savedX[1]; config.moveRightY = savedY[1];
        config.punchX     = savedX[2]; config.punchY     = savedY[2];
        config.kickX      = savedX[3]; config.kickY      = savedY[3];
        config.jumpX      = savedX[4]; config.jumpY      = savedY[4];
        config.blockX     = savedX[5]; config.blockY     = savedY[5];
        config.weaponX    = savedX[6]; config.weaponY    = savedY[6];
        config.magicX     = savedX[7]; config.magicY     = savedY[7];
        config.save(this);
    }

    // ─────────────────────────────────────────────────────────
    /** View vẽ các dấu chấm đã bấm */
    public static class CalibrateTouchView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final java.util.List<float[]> marks = new java.util.ArrayList<>();

        public CalibrateTouchView(Context ctx, android.util.AttributeSet attrs) {
            super(ctx, attrs);
        }

        public void addMark(int x, int y, int color, String label) {
            marks.add(new float[]{x, y, color, label.hashCode()});
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            for (float[] m : marks) {
                paint.setColor((int)m[2]);
                paint.setAlpha(200);
                canvas.drawCircle(m[0], m[1], 30, paint);
                paint.setColor(Color.WHITE);
                paint.setTextSize(28);
                canvas.drawText("✓", m[0]-10, m[1]+10, paint);
            }
        }
    }
}
