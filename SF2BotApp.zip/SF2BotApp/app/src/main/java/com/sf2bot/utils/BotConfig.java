package com.sf2bot.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Lưu/load tọa độ nút bấm và cài đặt bot
 */
public class BotConfig {
    private static final String PREFS = "sf2bot_config";

    // Tọa độ nút (tỷ lệ màn hình, tự tính khi load)
    public int punchX, punchY;
    public int kickX,  kickY;
    public int jumpX,  jumpY;
    public int blockX, blockY;
    public int moveLeftX,  moveLeftY;
    public int moveRightX, moveRightY;
    public int weaponX, weaponY;
    public int magicX,  magicY;

    // Settings
    public int targetFps   = 15;
    public boolean autoRetry = true;
    public boolean saveData  = true;

    public static BotConfig load(Context ctx) {
        BotConfig cfg = new BotConfig();
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        int w = dm.widthPixels, h = dm.heightPixels;

        // Tọa độ mặc định (tỷ lệ SF2 chuẩn)
        cfg.moveLeftX  = prefs.getInt("moveLeftX",  (int)(0.10f*w));
        cfg.moveLeftY  = prefs.getInt("moveLeftY",  (int)(0.82f*h));
        cfg.moveRightX = prefs.getInt("moveRightX", (int)(0.22f*w));
        cfg.moveRightY = prefs.getInt("moveRightY", (int)(0.82f*h));
        cfg.punchX     = prefs.getInt("punchX",     (int)(0.78f*w));
        cfg.punchY     = prefs.getInt("punchY",     (int)(0.72f*h));
        cfg.kickX      = prefs.getInt("kickX",      (int)(0.88f*w));
        cfg.kickY      = prefs.getInt("kickY",      (int)(0.82f*h));
        cfg.jumpX      = prefs.getInt("jumpX",      (int)(0.15f*w));
        cfg.jumpY      = prefs.getInt("jumpY",      (int)(0.68f*h));
        cfg.blockX     = prefs.getInt("blockX",     (int)(0.88f*w));
        cfg.blockY     = prefs.getInt("blockY",     (int)(0.68f*h));
        cfg.weaponX    = prefs.getInt("weaponX",    (int)(0.78f*w));
        cfg.weaponY    = prefs.getInt("weaponY",    (int)(0.60f*h));
        cfg.magicX     = prefs.getInt("magicX",     (int)(0.68f*w));
        cfg.magicY     = prefs.getInt("magicY",     (int)(0.82f*h));

        cfg.targetFps  = prefs.getInt("targetFps",  15);
        cfg.autoRetry  = prefs.getBoolean("autoRetry", true);
        cfg.saveData   = prefs.getBoolean("saveData",  true);
        return cfg;
    }

    public void save(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("moveLeftX",  moveLeftX).putInt("moveLeftY",  moveLeftY)
            .putInt("moveRightX", moveRightX).putInt("moveRightY", moveRightY)
            .putInt("punchX",     punchX).putInt("punchY",     punchY)
            .putInt("kickX",      kickX).putInt("kickY",      kickY)
            .putInt("jumpX",      jumpX).putInt("jumpY",      jumpY)
            .putInt("blockX",     blockX).putInt("blockY",     blockY)
            .putInt("weaponX",    weaponX).putInt("weaponY",    weaponY)
            .putInt("magicX",     magicX).putInt("magicY",     magicY)
            .putInt("targetFps",  targetFps)
            .putBoolean("autoRetry", autoRetry)
            .putBoolean("saveData",  saveData)
            .apply();
    }
}
